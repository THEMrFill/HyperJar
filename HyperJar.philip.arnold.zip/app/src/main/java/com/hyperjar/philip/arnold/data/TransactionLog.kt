package com.hyperjar.philip.arnold.data

data class TransactionLog(
    val items: List<ItemX>
)