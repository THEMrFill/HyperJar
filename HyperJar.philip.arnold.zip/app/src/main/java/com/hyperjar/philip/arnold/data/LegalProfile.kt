package com.hyperjar.philip.arnold.data

data class LegalProfile(
    val familyName: String,
    val givenName: String
)