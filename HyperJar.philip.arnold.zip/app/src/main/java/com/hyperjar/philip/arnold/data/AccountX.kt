package com.hyperjar.philip.arnold.data

data class AccountX(
    val id: String,
    val name: String
)