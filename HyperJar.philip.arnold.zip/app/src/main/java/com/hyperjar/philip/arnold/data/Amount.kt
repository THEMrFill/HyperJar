package com.hyperjar.philip.arnold.data

data class Amount(
    val currency: String,
    val totalAmount: String
)