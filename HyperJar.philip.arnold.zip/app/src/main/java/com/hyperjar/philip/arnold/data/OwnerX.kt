package com.hyperjar.philip.arnold.data

data class OwnerX(
    val id: String,
    val name: String
)