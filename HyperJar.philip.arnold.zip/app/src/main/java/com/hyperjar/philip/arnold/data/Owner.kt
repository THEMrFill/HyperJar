package com.hyperjar.philip.arnold.data

data class Owner(
    val id: String,
    val name: String
)