package com.hyperjar.philip.arnold.data

data class Account(
    val id: String,
    val name: String
)