package com.hyperjar.philip.arnold.data

data class FinancialSource(
    val account: Account,
    val owner: Owner
)