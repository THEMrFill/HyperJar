package com.hyperjar.philip.arnold.data

data class FinancialDestination(
    val account: AccountX,
    val owner: OwnerX
)